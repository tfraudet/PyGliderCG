COPY AUDITLOG FROM 'data/exported_db/auditlog.parquet' (FORMAT 'parquet');
COPY GLIDER FROM 'data/exported_db/glider.parquet' (FORMAT 'parquet');
COPY USERS FROM 'data/exported_db/users.parquet' (FORMAT 'parquet');
COPY INVENTORY FROM 'data/exported_db/inventory.parquet' (FORMAT 'parquet');
COPY WB_LIMIT FROM 'data/exported_db/wb_limit.parquet' (FORMAT 'parquet');
COPY WEIGHING FROM 'data/exported_db/weighing.parquet' (FORMAT 'parquet');
