

CREATE SEQUENCE auto_increment INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 15 NO CYCLE;
CREATE SEQUENCE inventory_id_seq INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 313 NO CYCLE;

CREATE TABLE GLIDER(model VARCHAR, registration VARCHAR PRIMARY KEY, brand VARCHAR, serial_number VARCHAR, single_seat BOOLEAN, datum INTEGER, pilot_position INTEGER, datum_label VARCHAR, wedge VARCHAR, wedge_position VARCHAR, mmwp FLOAT, mmwv FLOAT, mmenp FLOAT, mm_harnais FLOAT, weight_min_pilot FLOAT, front_centering FLOAT, rear_centering FLOAT, arm_front_pilot FLOAT, arm_rear_pilot FLOAT, arm_waterballast FLOAT, arm_front_ballast FLOAT, arm_rear_watterballast_or_ballast FLOAT, arm_gas_tank FLOAT, arm_instruments_panel FLOAT);
CREATE TABLE USERS(username VARCHAR PRIMARY KEY, email VARCHAR, "password" VARCHAR, "role" VARCHAR);
CREATE TABLE INVENTORY(id INTEGER DEFAULT(nextval('inventory_id_seq')) PRIMARY KEY, registration VARCHAR, on_board BOOLEAN, instrument VARCHAR, brand VARCHAR, "type" VARCHAR, number VARCHAR, date DATE, seat VARCHAR, FOREIGN KEY (registration) REFERENCES GLIDER(registration));
CREATE TABLE WB_LIMIT(registration VARCHAR, point_index INTEGER, center_of_gravity INTEGER, weight FLOAT, FOREIGN KEY (registration) REFERENCES GLIDER(registration));
CREATE TABLE WEIGHING(id INTEGER DEFAULT(nextval('auto_increment')) PRIMARY KEY, date DATE NOT NULL, registration VARCHAR, p1 DECIMAL(5,2), p2 DECIMAL(5,2), right_wing_weight DECIMAL(5,2), left_wing_weight DECIMAL(5,2), tail_weight DECIMAL(5,2), fuselage_weight DECIMAL(5,2), fix_ballast_weight DECIMAL(5,2) DEFAULT(0.0), A INTEGER DEFAULT(0), D INTEGER DEFAULT(0), FOREIGN KEY (registration) REFERENCES GLIDER(registration));




